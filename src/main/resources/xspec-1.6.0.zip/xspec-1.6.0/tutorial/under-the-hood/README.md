These files describe the internal behavior of XSpec. You'll want to look into them only when you're digging deep into how XSpec works under the hood.
