#### *.gif

Used by `../src/reporter/format-xspec-report-folding.xsl`

#### *.png

Embedded in `../src/reporter/test-report.css`.
See xspec/xspec#92, xspec/xspec#111, xspec/xspec#135 and xspec/xspec#524 for details.
