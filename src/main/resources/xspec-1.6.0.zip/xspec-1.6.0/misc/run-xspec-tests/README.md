These scripts used to be in `../../test/`.
