This `Makefile` used to be in `../../test/`.
